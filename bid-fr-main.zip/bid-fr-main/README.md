# bid-fr
<b>Module de traduction Babele pour le Systeme Blades in the Dark de megastruktur</b>

<p>Ce module rajoute le fichier fr.json pour traduire l'interface ainsi que la traduction des compendiums via babele.</p>

<p>* version 0.1.6 du 22 octobre 2022<br>Grosses mise à jour de réparation de toutes les traductions cassées</p>
<p>* version 0.1.5 du 31 août 2021<br>Ajouts de la traduction du compendium "Factions"</p>

<p>* version 0.1.5 du 31 août 2021<br>Le projet est passé sous gitlab.</p><p>Ajouts de la traduction du compendium "Factions"</p>

<p>* version 0.1.4 du 9 août 2021<br>Mise à jour du fichier fr.json en vu des prochaines mises à jours !</p><p><strong>Attention, le nom du module a changé, les majuscules ont été supprimées. Il faut mettre le lien babele à jour.</strong></p>
<p>* version 0.1.3 du 3 mars 2021<br>Amélioration du fichier fr.json et ajout des 3 livrets de Fentôme, Coquille et Vampire</p>
<p>* version 0.1.2 du 2 mars 2021<br>Traduction complète</p>
<p>* version 0.0.2 du 2 mars 2021<br>Version de travail - ajout de la traduction des équpipements</p>
<p>* version 0.0.1 du 2 mars 2021<br>Version de travail</p>
